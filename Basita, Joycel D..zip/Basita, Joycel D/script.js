document.addEventListener("DOMContentLoaded", function () {

    function showLabSelection() {
        document.getElementById("home-section").style.display = "none";
        document.getElementById("activities-section").style.display = "none";
        document.getElementById("lab-section").style.display = "block";
    }

    function showActivities(labNumber) {
        document.getElementById("home-section").style.display = "none";
        document.getElementById("lab-section").style.display = "none";
        document.getElementById("activities-section").style.display = "block";

        document.getElementById("lab1Activities").style.display = "none";
        document.getElementById("lab2Activities").style.display = "none";
        document.getElementById("lab4Activities").style.display = "none"; // Lab 4

        const labTitle = document.getElementById("labTitle");
        if (labNumber === 1) {
            document.getElementById("lab1Activities").style.display = "grid";
            labTitle.textContent = "Laboratory 2";
        } else if (labNumber === 2) {
            document.getElementById("lab2Activities").style.display = "grid";
            labTitle.textContent = "Laboratory 3";
        }else if (labNumber === 3) {
            document.getElementById("lab4Activities").style.display = "grid";
            labTitle.textContent = "Laboratory 4";
        }
    }

    function backToLabSelection() {
        document.getElementById("activities-section").style.display = "none";
        document.getElementById("lab-section").style.display = "block";
    }

    function showHome() {
        document.getElementById("lab-section").style.display = "none";
        document.getElementById("activities-section").style.display = "none";
        document.getElementById("home-section").style.display = "block";
    }

    window.showLabSelection = showLabSelection;
    window.showActivities = showActivities;
    window.backToLabSelection = backToLabSelection;
    window.showHome = showHome;

    // AKON LABORATORY 2
    function activity1() {
        alert("Welcome to JavaScript!");
        console.log("This is my first JS program.");
    }

    function activity2() {
        let name = "Joycel D. Basita BSCS 2C";
        let age = 21;
        let isStudent = true;

        console.log("Name:", name);
        console.log("Age:", age);
        console.log("Is Student:", isStudent);
        console.log("My name is " + name + ", I am " + age + " years old.");
    }

    function activity3() {
        let num1 = 16;
        let num2 = 4;

        console.log("Sum:", num1 + num2);
        console.log("Difference:", num1 - num2);
        console.log("Product:", num1 * num2);
        console.log("Quotient:", num1 / num2);
    }

    function activity4() {
        let userName = prompt("Enter your name:");
        let favoriteNumber = prompt("Enter your favorite number:");
        alert("Hello " + userName + "! Your favorite number is " + favoriteNumber + ".");
    }

    function activity5() {
        let userAge = Number(prompt("Enter your age:"));
        if (userAge >= 18) {
            alert("You are eligible.");
        } else {
            alert("You are not eligible.");
        }
    }

    function activity6() {
        console.log("For Loop (1 to 10)");
        for (let i = 1; i <= 10; i++) console.log(i);

        console.log("While Loop (10 to 1)");
        let j = 10;
        while (j >= 1) console.log(j--);
    }

    function activity7() {
        alert("Button Clicked!");
    }

    document.getElementById("btn1")?.addEventListener("click", activity1);
    document.getElementById("btn2")?.addEventListener("click", activity2);
    document.getElementById("btn3")?.addEventListener("click", activity3);
    document.getElementById("btn4")?.addEventListener("click", activity4);
    document.getElementById("btn5")?.addEventListener("click", activity5);
    document.getElementById("btn6")?.addEventListener("click", activity6);
    document.getElementById("btn7")?.addEventListener("click", activity7);

    // AKON LABORATORY 3
    function lab2Activity1() {
        const colors = ['#ff9999', '#99ff99', '#9999ff', '#ffff99', '#ffcc99'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        document.body.style.backgroundColor = randomColor;
    }

    function lab2Activity2() {
        if (document.body.style.backgroundColor === 'black') {
            document.body.style.backgroundColor = '';
            document.body.style.color = '';
        } else {
            document.body.style.backgroundColor = 'black';
            document.body.style.color = 'white';
        }
    }

    function lab2Activity3() {
    let ul = document.getElementById('lab2ItemList');
    let input = document.getElementById('lab2ItemInput');

    
    if (!ul || !input) {

        input = document.createElement('input');
        input.type = 'text';
        input.id = 'lab2ItemInput';
        input.placeholder = 'Enter list item...';

        ul = document.createElement('ul');
        ul.id = 'lab2ItemList';

        document.getElementById('lab2btn3').before(input, ul);

    } else if (input.value.trim() !== '') {
       
        const li = document.createElement('li');
        li.textContent = input.value;
        ul.appendChild(li);

        input.value = ''; 
    }
}

    function lab2Activity4() {
        let para = document.getElementById('lab2Para');
        if (!para) {
            para = document.createElement('p');
            para.id = 'lab2Para';
            para.textContent = 'MAWAWARA INE!';
            document.getElementById('lab2btn4').before(para);
        } else {
            para.remove();
        }
    }

    function lab2Activity5() {
        let input = document.getElementById('lab2CharInput');
        if (!input) {
            input = document.createElement('input');
            input.type = 'text';
            input.id = 'lab2CharInput';
            input.placeholder = 'Type something...';

            const counter = document.createElement('p');
            counter.innerHTML = 'Characters typed: <span id="lab2CharCount">0</span>';

            document.getElementById('lab2btn5').before(input, counter);

            input.addEventListener('input', (e) => {
                document.getElementById('lab2CharCount').textContent = e.target.value.length;
            });
        }
    }

    function lab2Activity6() {
        let num1 = document.getElementById('lab2Num1');
        let num2 = document.getElementById('lab2Num2');
        let resultSpan = document.getElementById('lab2CalcResult');

        if (!num1 || !num2 || !resultSpan) {
            num1 = document.createElement('input');
            num1.type = 'number';
            num1.id = 'lab2Num1';
            num1.placeholder = 'Number 1';

            num2 = document.createElement('input');
            num2.type = 'number';
            num2.id = 'lab2Num2';
            num2.placeholder = 'Number 2';

            const result = document.createElement('p');
            result.innerHTML = 'Result: <span id="lab2CalcResult">0</span>';

            document.getElementById('lab2btn6').before(num1, num2, result);
        } else {
            const sum = (parseFloat(num1.value) || 0) + (parseFloat(num2.value) || 0);
            resultSpan.textContent = sum;
        }
    }

    function lab2Activity7() {
        const img = document.getElementById('lab2Image');
        if (img.src.includes('photo1.jpg')) {
            img.src = 'images/photo2.jpg';
        } else {
            img.src = 'images/photo1.jpg';
        }
    }

    function lab2Activity8() {
        let input = document.getElementById('lab2TodoInput');
        let ul = document.getElementById('lab2TodoList');
        
        if (!input || !ul) {
            input = document.createElement('input');
            input.id = 'lab2TodoInput';
            input.placeholder = 'New task';

            ul = document.createElement('ul');
            ul.id = 'lab2TodoList';

            document.getElementById('lab2btn8').before(input, ul);
        } else if (input.value.trim() !== '') {
            const li = document.createElement('li');
            li.textContent = input.value;
            ul.appendChild(li);
            input.value = '';
        }
    }

    document.getElementById('lab2btn1')?.addEventListener('click', lab2Activity1);
    document.getElementById('lab2btn2')?.addEventListener('click', lab2Activity2);
    document.getElementById('lab2btn3')?.addEventListener('click', lab2Activity3);
    document.getElementById('lab2btn4')?.addEventListener('click', lab2Activity4);
    document.getElementById('lab2btn5')?.addEventListener('click', lab2Activity5);
    document.getElementById('lab2btn6')?.addEventListener('click', lab2Activity6);
    document.getElementById('lab2btn7')?.addEventListener('click', lab2Activity7);
    document.getElementById('lab2btn8')?.addEventListener('click', lab2Activity8);

});

function setupLab4Calculator() {
  const quizContainer = document.getElementById('quizContainer');
  const examContainer = document.getElementById('examContainer');
  const mcoContainer = document.getElementById('mcoContainer');

  const numQuizzesInput = document.getElementById('numQuizzes');
  const generateQuizBtn = document.getElementById('generateQuizzes');

  const numExamsInput = document.getElementById('numExams');
  const generateExamBtn = document.getElementById('generateExams');

  const numMCOsInput = document.getElementById('numMCOs');
  const generateMCOBtn = document.getElementById('generateMCOs');

  const quizAverageDisplay = document.querySelector('.quizAverage');
  const examDisplay = document.querySelector('.examDisplay');
  const mcoDisplay = document.querySelector('.mcoDisplay');
  const resultDiv = document.querySelector('.result');
  const resetBtn = document.querySelector('.resetBtn');

  let quizInputs = [];
  let examInputs = [];
  let mcoInputs = [];

  // --- Generate Quiz Inputs ---
  generateQuizBtn.addEventListener('click', () => {
    quizContainer.innerHTML = '';
    quizInputs = [];
    const n = parseInt(numQuizzesInput.value) || 1;
    for (let i = 1; i <= n; i++) {
      const label = document.createElement('label');
      label.textContent = `Quiz ${i} (0-100)`;
      const input = document.createElement('input');
      input.type = 'number';
      input.min = 0;
      input.max = 100;
      input.classList.add('quiz');
      quizContainer.appendChild(label);
      quizContainer.appendChild(input);
      quizInputs.push(input);
      input.addEventListener('input', calculateFinalGrade);
    }
    calculateFinalGrade();
  });

  // --- Generate Exam Inputs ---
  generateExamBtn.addEventListener('click', () => {
    examContainer.innerHTML = '';
    examInputs = [];
    const n = parseInt(numExamsInput.value) || 1;
    for (let i = 1; i <= n; i++) {
      const label = document.createElement('label');
      label.textContent = `Exam ${i} (0-100)`;
      const input = document.createElement('input');
      input.type = 'number';
      input.min = 0;
      input.max = 100;
      input.classList.add('exam');
      examContainer.appendChild(label);
      examContainer.appendChild(input);
      examInputs.push(input);
      input.addEventListener('input', calculateFinalGrade);
    }
    calculateFinalGrade();
  });

  // --- Generate MCO Inputs ---
  generateMCOBtn.addEventListener('click', () => {
    mcoContainer.innerHTML = '';
    mcoInputs = [];
    const n = parseInt(numMCOsInput.value) || 1;
    for (let i = 1; i <= n; i++) {
      const label = document.createElement('label');
      label.textContent = `MCO ${i} (0-100)`;
      const input = document.createElement('input');
      input.type = 'number';
      input.min = 0;
      input.max = 100;
      input.classList.add('mco');
      mcoContainer.appendChild(label);
      mcoContainer.appendChild(input);
      mcoInputs.push(input);
      input.addEventListener('input', calculateFinalGrade);
    }
    calculateFinalGrade();
  });

  // --- Calculate Averages ---
  function calculateAverage(inputs) {
    const total = inputs.reduce((sum, input) => sum + (parseFloat(input.value) || 0), 0);
    return total / (inputs.length || 1);
  }

  function calculateFinalGrade() {
    const quizAvg = calculateAverage(quizInputs);
    const examAvg = calculateAverage(examInputs);
    const mcoAvg = calculateAverage(mcoInputs);

    quizAverageDisplay.textContent = `Quiz Average: ${quizAvg.toFixed(2)}`;
    examDisplay.textContent = `Exam Average: ${examAvg.toFixed(2)}`;
    mcoDisplay.textContent = `MCO Average: ${mcoAvg.toFixed(2)}`;

    // Adjust weights here
    const finalGrade = (quizAvg * 0.2) + (examAvg * 0.3) + (mcoAvg * 0.5);

    let letter;
    if (finalGrade >= 90) letter = 'A';
    else if (finalGrade >= 80) letter = 'B';
    else if (finalGrade >= 70) letter = 'C';
    else if (finalGrade >= 60) letter = 'D';
    else letter = 'F';

    resultDiv.innerHTML = `Final Grade: ${finalGrade.toFixed(2)} <br> Letter Grade: ${letter}`;
  }

  // --- Reset ---
  resetBtn.addEventListener('click', () => {
    quizContainer.innerHTML = '';
    examContainer.innerHTML = '';
    mcoContainer.innerHTML = '';
    quizInputs = [];
    examInputs = [];
    mcoInputs = [];
    numQuizzesInput.value = 3;
    numExamsInput.value = 2;
    numMCOsInput.value = 2;
    quizAverageDisplay.textContent = '';
    examDisplay.textContent = '';
    mcoDisplay.textContent = '';
    resultDiv.innerHTML = '';
  });
}

document.addEventListener('DOMContentLoaded', setupLab4Calculator);