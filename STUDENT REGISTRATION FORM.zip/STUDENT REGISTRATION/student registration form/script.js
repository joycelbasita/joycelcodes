const form = document.getElementById("studentForm");
const output = document.getElementById("output");
const clearBtn = document.getElementById("clearBtn");

form.addEventListener("submit", function(event) {
    event.preventDefault(); // prevent page refresh

    const name = document.getElementById("name").value.trim();
    const course = document.getElementById("course").value.trim();
    const year = document.getElementById("year").value.trim();
    const section = document.getElementById("section").value.trim();
    const email = document.getElementById("email").value.trim();

    // check if any field is empty
    if (!name || !course || !year || !section || !email) {
        alert("Please fill in all fields.");
        return;
    }

    // display data
    output.innerHTML = `
        <strong>Name:</strong> ${name}<br>
        <strong>Course:</strong> ${course}<br>
        <strong>Year Level:</strong> ${year}<br>
        <strong>Section:</strong> ${section}<br>
        <strong>Email:</strong> ${email}
    `;
});

clearBtn.addEventListener("click", function() {
    // clear inputs
    document.getElementById("name").value = "";
    document.getElementById("course").value = "";
    document.getElementById("year").value = "";
    document.getElementById("section").value = "";
    document.getElementById("email").value = "";

    // clear preview
    output.innerHTML = "";
});